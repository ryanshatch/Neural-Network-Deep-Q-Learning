```python
"""
* CS-370 | Current/ Emerging Trends in Computer Science - 2024
* Author:              Ryan Hatch
* Date of Development: Mon Nov 24th 06:26:26 2024 
* Last Modified:       Tues Dec 30rd 12:21:21 2024
* Version:             2.2.6
"""
```




    '\n* CS-370 | Current/ Emerging Trends in Computer Science - 2024\n* Author:              Ryan Hatch\n* Date of Development: Mon Nov 24th 06:26:26 2024 \n* Last Modified:       Tues Dec 30rd 12:21:21 2024\n* Version:             2.2.6\n'



# *Treasure Hunt Game Notebook*
<hr>

##### The theme of this project is a popular treasure hunt game in which the player needs to find the treasure before the pirate does. The pirate will try to find the optimal path to the treasure using deep Q-learning. 
<!-- While you will not be developing the entire game, you will write the part of the game that represents the intelligent agent, which is a pirate in this case. -->
##### The first class, `TreasureMaze.py`, represents the environment, which includes a maze object defined as a matrix. The second class, `GameExperience.py`, stores the episodes – that is, all the states that come in between the initial state and the terminal state. This is later used by the agent for learning by experience, called `"exploration"`. 

<!-- This notebook shows how to play a game. Your task is to complete the deep Q-learning implementation for which a skeleton implementation has been provided. The code blocks you will need to complete has #TODO as a header. -->

<!-- First, read and review the next few code and instruction blocks to understand the code that you have been given. -->


```python
from __future__ import print_function
import os, sys, time, datetime, json, random
import numpy as np
from keras.models import Sequential
from keras.layers.core import Dense, Activation
from keras.optimizers import SGD , Adam, RMSprop
from keras.layers.advanced_activations import PReLU
import matplotlib.pyplot as plt
from TreasureMaze import TreasureMaze
from GameExperience import GameExperience
%matplotlib inline
```

    Using TensorFlow backend.
    

#### The following code block contains an 8x8 matrix that will be used as a maze object:


```python
maze = np.array([
    [ 1.,  0.,  1.,  1.,  1.,  1.,  1.,  1.],
    [ 1.,  0.,  1.,  1.,  1.,  0.,  1.,  1.],
    [ 1.,  1.,  1.,  1.,  0.,  1.,  0.,  1.],
    [ 1.,  1.,  1.,  0.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  0.,  1.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  1.,  0.,  1.,  0.,  0.,  0.],
    [ 1.,  1.,  1.,  0.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  1.,  1.,  0.,  1.,  1.,  1.]
])
```

#### This helper function allows a visual representation of the maze object:


```python
def show(qmaze):
    plt.grid('on')
    nrows, ncols = qmaze.maze.shape
    ax = plt.gca()
    ax.set_xticks(np.arange(0.5, nrows, 1))
    ax.set_yticks(np.arange(0.5, ncols, 1))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    canvas = np.copy(qmaze.maze)
    for row,col in qmaze.visited:
        canvas[row,col] = 0.6
    pirate_row, pirate_col, _ = qmaze.state
    canvas[pirate_row, pirate_col] = 0.3   # pirate cell
    canvas[nrows-1, ncols-1] = 0.9 # treasure cell
    img = plt.imshow(canvas, interpolation='none', cmap='gray')
    return img
```

##### The pirate agent can move in four directions: left, right, up, and down.

##### While the agent primarily learns by experience through exploitation, often, the agent can choose to explore the environment to find previously undiscovered paths.

##### This is called `exploration` and is defined by epsilon. This value is typically a lower value such as 0.1, which means for every ten attempts, the agent will attempt to learn by experience nine times and will randomly explore a new path one time. You are encouraged to try various values for the exploration factor and see how the algorithm performs.


```python
LEFT = 0
UP = 1
RIGHT = 2
DOWN = 3


# Exploration factor
epsilon = 0.1

# Actions dictionary
actions_dict = {
    LEFT: 'left',
    UP: 'up',
    RIGHT: 'right',
    DOWN: 'down',
}

# Number of possible actions
num_actions = len(actions_dict)

```

#### The sample code block and output below show creating a maze object and performing one action (DOWN), which returns the reward. The resulting updated environment is visualized.


```python
qmaze = TreasureMaze(maze)
canvas, reward, game_over = qmaze.act(DOWN)
print("reward=", reward)
show(qmaze)

# # qmaze = TreasureMaze(maze)
# # envstate, reward, game_status = qmaze.act(DOWN)
# # print("reward=", reward)
# # show(qmaze)

# qmaze = TreasureMaze(maze)
# canvas, reward, game_over = qmaze.act(DOWN)
# print("reward=", reward)
# show(qmaze)
```

    reward= -0.04
    




    <matplotlib.image.AxesImage at 0x26065476408>




![png](output_10_2.png)


#### This function simulates a full game based on the provided trained model. The other parameters include the TreasureMaze object and the starting position of the pirate.


```python
def play_game(model, qmaze, pirate_cell):
    qmaze.reset(pirate_cell)
    envstate = qmaze.observe()
    while True:
        prev_envstate = envstate
        # get next action
        q = model.predict(prev_envstate)
        action = np.argmax(q[0])

        # apply action, get rewards and new state
        envstate, reward, game_status = qmaze.act(action)
        if game_status == 'win':
            return True
        elif game_status == 'lose':
            return False

# # def play_game(model, qmaze, pirate_cell):
# #     qmaze.reset(pirate_cell)
# #     envstate = qmaze.observe()
# #     while True:
# #         prev_envstate = envstate
# #         # get next action
# #         q = model.predict(prev_envstate)
# #         action = np.argmax(q[0])

# #         # apply action, get rewards and new state
# #         envstate, reward, game_status = qmaze.act(action)
# #         if game_status == 'win':
# #             return True
# #         elif game_status == 'lose':
# #             return False

# def play_game(model, qmaze, pirate_cell):
#     qmaze.reset(pirate_cell)
#     envstate = qmaze.observe()
#     while True:
#         prev_envstate = envstate
#         # get next action
#         q = model.predict(prev_envstate)
#         action = np.argmax(q[0])

#         # apply action, get rewards and new state
#         envstate, reward, game_status = qmaze.act(action)
#         if game_status == 'win':
#             return True
#         elif game_status == 'lose':
#             return False
```

#### This function helps you to determine whether the pirate can win any game at all. If your maze is not well designed, the pirate may not win any game at all. 
#### In this case, your training would not yield any result. 
<!-- The provided maze in this notebook ensures that there is a path to win and you can run this method to check. -->


```python
def completion_check(model, qmaze):
    for cell in qmaze.free_cells:
        if not qmaze.valid_actions(cell):
            return False
        if not play_game(model, qmaze, cell):
            return False
    return True
```


```python
"""
Builds a neural network model using Keras Sequential API.

Parameters:
- maze: The maze environment as a NumPy array.

Returns:
- model: Compiled Keras model.
"""
```




    '\nBuilds a neural network model using Keras Sequential API.\n\nParameters:\n- maze: The maze environment as a NumPy array.\n\nReturns:\n- model: Compiled Keras model.\n'




```python
def build_model(maze):
    model = Sequential()
    model.add(Dense(maze.size, input_shape=(maze.size,)))
    model.add(PReLU())
    model.add(Dense(maze.size))
    model.add(PReLU())
    model.add(Dense(num_actions))
    model.compile(optimizer='adam', loss='mse')
    return model
```

<!-- ## TODO: Complete the Q-Training Algorithm Code Block -->

#### The Q-learning algorithm is a model-free, reinforcement learning algorithm. The goal of Q-learning is to learn a policy, which tells an agent what action to take under what circumstances. It does not require a model of the environment and can handle problems with stochastic transitions and rewards without requiring adaptations. 

#### *The goal of this model is to be trained and then used to find the treasure in the maze.*

<!-- 
#### This is your deep Q-learning implementation. The goal of your deep Q-learning implementation is to find the best possible navigation sequence that results in reaching the treasure cell while maximizing the reward. In your implementation, you need to determine the optimal number of epochs to achieve a 100% win rate.

#### You will need to complete the section starting with #pseudocode. The pseudocode has been included for you. -->


```python
"""
Trains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.

Parameters:
- model: The neural network model to be trained.
- maze: The maze environment as a NumPy array.
- **opt: Optional parameters including:
    - n_epoch: Number of training epochs (default: 15000)
    - max_memory: Maximum number of episodes to store in memory (default: 1000)
    - data_size: Number of samples to train on per epoch (default: 50)
    - epsilon: Initial exploration factor (default: 0.1)

Returns:
- seconds: Total training time in seconds.
"""
```




    '\nTrains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.\n\nParameters:\n- model: The neural network model to be trained.\n- maze: The maze environment as a NumPy array.\n- **opt: Optional parameters including:\n    - n_epoch: Number of training epochs (default: 15000)\n    - max_memory: Maximum number of episodes to store in memory (default: 1000)\n    - data_size: Number of samples to train on per epoch (default: 50)\n    - epsilon: Initial exploration factor (default: 0.1)\n\nReturns:\n- seconds: Total training time in seconds.\n'




```python
def qtrain(model, maze, **opt):

    # exploration factor
    global epsilon 

    # number of epochs
    n_epoch = opt.get('n_epoch', 15000)

    # maximum memory to store episodes
    max_memory = opt.get('max_memory', 1000)

    # maximum data size for training
    data_size = opt.get('data_size', 50)

    # start time
    start_time = datetime.datetime.now()

    # Construct environment/game from numpy array: maze (see above)
    qmaze = TreasureMaze(maze)

    # Initialize experience replay object
    experience = GameExperience(model, max_memory=max_memory)
    
    win_history = []   # history of win/lose game
    hsize = qmaze.maze.size//2   # history window size
    win_rate = 0.0
    
    # **** Q-learning algorithm ****
    for epoch in range(n_epoch):
        loss = 0.0       
        # Select random agent cell
        agent_cell = random.choice(qmaze.free_cells)
        # Set agent in random cell
        qmaze.reset(agent_cell)
        envstate = qmaze.observe()
        n_episodes = 0
        
        while qmaze.game_status() == 'not_over':
            valid_actions = qmaze.valid_actions()
            if not valid_actions: break
            previous_envstate = envstate
        
            # Retrieve next random action
            if np.random.rand() < epsilon:
                action = random.choice(valid_actions)
            else:
                action = np.argmax(experience.predict(previous_envstate))
        
            # Agent takes action
            envstate, reward, game_status = qmaze.act(action)
            
            # Pirate won
            if game_status == 'win':
                win_history.append(1)
                win_rate = sum(win_history) / len(win_history)
                break
            # Pirate lost
            elif game_status == 'lose':
                win_history.append(0)
                win_rate = sum(win_history) / len(win_history)
                break
            # Continues game if pirate has not won or lost yet
        
            # Stores episode in experience replay
            episode = [previous_envstate, action, reward, envstate, game_status]
            experience.remember(episode)
            # Increment the episode count 
            n_episodes += 1
            
            # Train neural network model and evaluate loss
            inputs,targets = experience.get_data(data_size=data_size)
            history = model.fit(inputs, targets, epochs=8, batch_size=16, verbose=0)
            loss = model.evaluate(inputs, targets, verbose = 0)
        
        # Check if the win rate is above threshold
        if win_rate > epsilon:
            print('Win rate above threshold')
            if completion_check(model, qmaze) == True:
                print('Model passed completion check')
    
    #Print the epoch, loss, episodes, win count, and win rate for each epoch
        dt = datetime.datetime.now() - start_time
        t = format_time(dt.total_seconds())
        template = "Epoch: {:03d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | time: {}"
        print(template.format(epoch, n_epoch-1, loss, n_episodes, sum(win_history), win_rate, t))
        # We simply check if training has exhausted all free cells and if in all
        # cases the agent won.
        if win_rate > 0.9 : epsilon = 0.05
        if sum(win_history[-hsize:]) == hsize and completion_check(model, qmaze):
            print("Reached 100%% win rate at epoch: %d" % (epoch,))
            break
    
    
    # Determine the total time for training
    dt = datetime.datetime.now() - start_time
    seconds = dt.total_seconds()
    t = format_time(seconds)

    print("n_epoch: %d, max_mem: %d, data: %d, time: %s" % (epoch, max_memory, data_size, t))
    return seconds

# This is a small utility for printing readable time strings:
def format_time(seconds):
    if seconds < 400:
        s = float(seconds)
        return "%.1f seconds" % (s,)
    elif seconds < 4000:
        m = seconds / 60.0
        return "%.2f minutes" % (m,)
    else:
        h = seconds / 3600.0
        return "%.2f hours" % (h,)
```


```python
# def qtrain(model, maze, **opt):
#     """
#     Trains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.
    
#     Parameters:
#     - model: The neural network model to be trained.
#     - maze: The maze environment as a NumPy array.
#     - **opt: Optional parameters including:
#         - n_epoch: Number of training epochs (default: 15000)
#         - max_memory: Maximum number of episodes to store in memory (default: 1000)
#         - data_size: Number of samples to train on per epoch (default: 50)
#         - epsilon: Initial exploration factor (default: 0.1)
    
#     Returns:
#     - seconds: Total training time in seconds.
#     """
    
#     # Define the format_time function within qtrain
#     def format_time(seconds):
#         """
#         Converts a time duration from seconds to a human-readable string.

#         Parameters:
#         - seconds (float): Time duration in seconds.

#         Returns:
#         - str: Human-readable time string.
#         """
#         if seconds < 60:
#             return f"{seconds:.1f} seconds"
#         elif seconds < 3600:
#             minutes = seconds / 60
#             return f"{minutes:.2f} minutes"
#         else:
#             hours = seconds / 3600
#             return f"{hours:.2f} hours"

#     # Retrieve optional parameters or set to default values
#     n_epoch = opt.get('n_epoch', 15000)          # Total number of training epochs
#     max_memory = opt.get('max_memory', 1000)     # Maximum episodes to store in memory
#     data_size = opt.get('data_size', 50)         # Number of training samples per epoch
#     epsilon = opt.get('epsilon', 0.1)            # Initial exploration factor
    
#     # Record the start time to monitor training duration
#     start_time = datetime.datetime.now()
    
#     #* Initialize the maze environment
#     qmaze = TreasureMaze(maze)
    
#     # Initialize the experience replay memory
#     experience = GameExperience(model, max_memory=max_memory)
    
#     #* Initialize variables to track training progress
#     win_history = []                  # History of game outcomes (1 for win, 0 for loss)
#     hsize = qmaze.maze.size // 2      # Window size for calculating win rate
#     win_rate = 0.0                    # Current win rate
    
#     # Iterate over each epoch
#     for epoch in range(n_epoch):
#         # Randomly select a free cell as the pirate's starting position
#         agent_cell = random.choice(qmaze.free_cells)
        
#         # Reset the maze environment with the pirate at the selected starting position
#         qmaze.reset(agent_cell)
        
#         # Observe the current state of the environment
#         envstate = qmaze.observe()
        
#         # Initialize variables for the current episode
#         game_over = False               # Flag to determine if the game has ended
#         n_episodes = 0                  # Number of steps taken in the current epoch
#         win = False                     # Flag to indicate if the current episode is a win
        
#         # Continue interacting with the environment until the game is over
#         while not game_over:
#             # Store the previous state for experience replay
#             prev_envstate = envstate.copy()
            
#             # Decide whether to explore or exploit based on the epsilon-greedy strategy
#             if random.random() < epsilon:
#                 #* Exploration: choose a random valid action
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     action = random.choice(valid_actions)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
#             else:
#                 #* Exploitation: choose the best action based on current Q-values
#                 q_values = experience.predict(prev_envstate)
                
#                 # Retrieve valid actions to mask invalid ones
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     # Initialize Q-values for all actions as -infinity
#                     q_values_invalid = np.full(num_actions, -np.inf)
#                     # Assign actual Q-values to valid actions
#                     q_values_invalid[valid_actions] = q_values[valid_actions]
#                     # Select the action with the highest Q-value among valid actions
#                     action = np.argmax(q_values_invalid)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
            
#             # Execute the chosen action in the environment
#             if action is not None:
#                 envstate, reward, game_status = qmaze.act(action)
#             else:
#                 # Assign a penalty if the agent is blocked
#                 game_status = 'lose'
#                 reward = -1.0  # Penalty for being blocked
            
#             # Increment the number of steps taken
#             n_episodes += 1
            
#             # Determine if the game has ended
#             game_over = game_status in ['win', 'lose']
            
#             # Store the transition (episode) in experience replay memory
#             episode = [prev_envstate, action, reward, envstate, game_over]
#             experience.remember(episode)
            
#             # Update the win history if the game has ended
#             if game_over:
#                 win = 1 if game_status == 'win' else 0
#                 win_history.append(win)
        
#         # Train the neural network model if enough experiences are available
#         if len(experience.memory) >= data_size:
#             # Retrieve a batch of experiences for training
#             inputs, targets = experience.get_data(data_size=data_size)
            
#             # Train the model on the retrieved batch
#             history = model.fit(inputs, targets, epochs=1, verbose=0)
            
#             # Extract the loss value from the training history
#             loss = history.history['loss'][0]
#         else:
#             # Not enough experiences to train; set loss to None
#             loss = None
        
#         # Calculate the win rate over the most recent hsize episodes
#         if len(win_history) >= hsize:
#             recent_wins = win_history[-hsize:]
#             win_rate = sum(recent_wins) / hsize
#         else:
#             recent_wins = win_history
#             win_rate = sum(recent_wins) / len(recent_wins) if recent_wins else 0.0
        
#         # Calculate the elapsed time since training started
#         dt = datetime.datetime.now() - start_time
#         t = format_time(dt.total_seconds())
        
#         # Prepare the template for epoch information display
#         template = "Epoch: {:05d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | Time: {}"
        
#         # Display loss as 0.0 if it's None to avoid formatting issues
#         loss_display = loss if loss is not None else 0.0
        
#         # Print the current epoch's training information
#         print(template.format(epoch+1, n_epoch, loss_display, n_episodes, sum(win_history[-hsize:]), win_rate, t))
        
#         # Gradually decrease the exploration factor epsilon if the win rate is high
#         if win_rate > 0.9:
#             epsilon = max(epsilon * 0.995, 0.05)  # Ensure epsilon doesn't fall below 0.05
        
#         # Early stopping condition: if win rate is 100% over the window and the agent passes the completion check
#         if win_rate == 1.0 and completion_check(model, qmaze):
#             print("Reached 100% win rate at epoch: {}".format(epoch+1))
#             break
    
#     # Calculate the total training time
#     dt = datetime.datetime.now() - start_time
#     seconds = dt.total_seconds()
#     t = format_time(seconds)
    
#     # Print the training summary
#     print("Training completed in epoch: {}, max_memory: {}, data_size: {}, time: {}".format(epoch+1, max_memory, data_size, t))
    
#     return seconds

```


```python
#* Version 2:

#
#* Version 2.2
# def qtrain(model, maze, **opt):
#     """
#     Trains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.
    
#     Parameters:
#     - model: The neural network model to be trained.
#     - maze: The maze environment as a NumPy array.
#     - **opt: Optional parameters including:
#         - n_epoch: Number of training epochs (default: 15000)
#         - max_memory: Maximum number of episodes to store in memory (default: 1000)
#         - data_size: Number of samples to train on per epoch (default: 50)
    
#     Returns:
#     - seconds: Total training time in seconds.
#     """
    
#     # Access the global exploration factor
#     global epsilon 
    
#     # Retrieve optional parameters or set to default values
#     n_epoch = opt.get('n_epoch', 15000)          # Total number of training epochs
#     max_memory = opt.get('max_memory', 1000)     # Maximum episodes to store in memory
#     data_size = opt.get('data_size', 50)         # Number of training samples per epoch
    
#     # Record the start time to monitor training duration
#     start_time = datetime.datetime.now()
    
#     # Initialize the maze environment
#     qmaze = TreasureMaze(maze)
    
#     # Initialize the experience replay memory
#     experience = GameExperience(model, max_memory=max_memory)
    
#     # Initialize variables to track training progress
#     win_history = []                  # History of game outcomes (1 for win, 0 for loss)
#     hsize = qmaze.maze.size // 2      # Window size for calculating win rate
#     win_rate = 0.0                     # Current win rate
    
#     # Iterate over each epoch
#     for epoch in range(n_epoch):
#         # Randomly select a free cell as the pirate's starting position
#         agent_cell = random.choice(qmaze.free_cells)
        
#         # Reset the maze environment with the pirate at the selected starting position
#         qmaze.reset(agent_cell)
        
#         # Observe the current state of the environment
#         envstate = qmaze.observe()
        
#         # Initialize variables for the current episode
#         game_over = False               # Flag to determine if the game has ended
#         n_episodes = 0                  # Number of steps taken in the current epoch
#         win = False                     # Flag to indicate if the current episode is a win
        
#         # Continue interacting with the environment until the game is over
#         while not game_over:
#             # Store the previous state for experience replay
#             prev_envstate = envstate.copy()
            
#             # Decide whether to explore or exploit based on epsilon-greedy strategy
#             if random.random() < epsilon:
#                 # Exploration: choose a random valid action
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     action = random.choice(valid_actions)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
#             else:
#                 # Exploitation: choose the best action based on current Q-values
#                 q_values = experience.predict(prev_envstate)
                
#                 # Retrieve valid actions to mask invalid ones
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     # Initialize Q-values for all actions as -infinity
#                     q_values_invalid = np.full(num_actions, -np.inf)
#                     # Assign actual Q-values to valid actions
#                     q_values_invalid[valid_actions] = q_values[valid_actions]
#                     # Select the action with the highest Q-value among valid actions
#                     action = np.argmax(q_values_invalid)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
            
#             # Execute the chosen action in the environment
#             if action is not None:
#                 envstate, reward, game_status = qmaze.act(action)
#             else:
#                 # Assign a penalty if the agent is blocked
#                 game_status = 'lose'
#                 reward = -1.0  # Penalty for being blocked
            
#             # Increment the number of steps taken
#             n_episodes += 1
            
#             # Determine if the game has ended
#             game_over = game_status in ['win', 'lose']
            
#             # Store the transition (episode) in experience replay memory
#             episode = [prev_envstate, action, reward, envstate, game_over]
#             experience.remember(episode)
            
#             # Update the win history if the game has ended
#             if game_over:
#                 win = 1 if game_status == 'win' else 0
#                 win_history.append(win)
        
#         # Train the neural network model if enough experiences are available
#         if len(experience.memory) >= data_size:
#             # Retrieve a batch of experiences for training
#             inputs, targets = experience.get_data(data_size=data_size)
            
#             # Train the model on the retrieved batch
#             history = model.fit(inputs, targets, epochs=1, verbose=0)
            
#             # Extract the loss value from the training history
#             loss = history.history['loss'][0]
#         else:
#             # Not enough experiences to train; set loss to None
#             loss = None
        
#         # Calculate the win rate over the most recent hsize episodes
#         if len(win_history) >= hsize:
#             recent_wins = win_history[-hsize:]
#             win_rate = sum(recent_wins) / hsize
#         else:
#             recent_wins = win_history
#             win_rate = sum(recent_wins) / len(recent_wins) if recent_wins else 0.0
        
#         # Calculate the elapsed time since training started
#         dt = datetime.datetime.now() - start_time
#         t = format_time(dt.total_seconds())
        
#         # Prepare the template for epoch information display
#         template = "Epoch: {:05d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | Time: {}"
        
#         # Display loss as 0.0 if it's None to avoid formatting issues
#         loss_display = loss if loss is not None else 0.0
        
#         # Print the current epoch's training information
#         print(template.format(epoch+1, n_epoch, loss_display, n_episodes, sum(win_history[-hsize:]), win_rate, t))
        
#         # Gradually decrease the exploration factor epsilon if the win rate is high
#         if win_rate > 0.9:
#             epsilon = max(epsilon * 0.995, 0.05)  # Ensure epsilon doesn't fall below 0.05
        
#         # Early stopping condition: if win rate is 100% over the window and the agent passes the completion check
#         if win_rate == 1.0 and completion_check(model, qmaze):
#             print("Reached 100% win rate at epoch: {}".format(epoch+1))
#             break
    
#     # Calculate the total training time
#     dt = datetime.datetime.now() - start_time
#     seconds = dt.total_seconds()
#     t = format_time(seconds)
    
#     # Print the training summary
#     print("Training completed in epoch: {}, max_memory: {}, data_size: {}, time: {}".format(epoch+1, max_memory, data_size, t))
    
#     return seconds
```

### *Test Your Model*

#### Now we will start testing the deep Q-learning implementation. To begin, select `Cell`, then `Run All` from the menu bar. This will run your notebook. As it runs, you should see output begin to appear beneath the next few cells. The code below creates an instance of TreasureMaze.


```python
# Initialize the TreasureMaze environment
qmaze = TreasureMaze(maze)
show(qmaze)

# qmaze = TreasureMaze(maze)
```




    <matplotlib.image.AxesImage at 0x26065b6ba88>




![png](output_23_1.png)


#### In the next code block, you will build your model and train it using deep Q-learning. Note: This step takes several minutes to fully run.


```python
# Train the model using deep Q-learning
model = build_model(maze)
qtrain(model, maze, epochs=1000, max_memory=8*maze.size, data_size=32)

# model = build_model(maze)
# training_time = qtrain(model, maze, n_epoch=10000, max_memory=8*maze.size, data_size=32)

# training_time = qtrain(model, maze, n_epoch=10000, max_memory=8*maze.size, data_size=32)

# qtrain(model, maze, epochs=1000, max_memory=8*maze.size, data_size=32)
```

    Epoch: 000/14999 | Loss: 0.0000 | Episodes: 133 | Win count: 0 | Win rate: 0.000 | time: 13.1 seconds
    Win rate above threshold
    Epoch: 001/14999 | Loss: 0.0005 | Episodes: 77 | Win count: 1 | Win rate: 0.500 | time: 20.2 seconds
    Win rate above threshold
    Epoch: 002/14999 | Loss: 0.0004 | Episodes: 87 | Win count: 2 | Win rate: 0.667 | time: 28.6 seconds
    Win rate above threshold
    Epoch: 003/14999 | Loss: 0.0008 | Episodes: 136 | Win count: 2 | Win rate: 0.500 | time: 41.1 seconds
    Win rate above threshold
    Epoch: 004/14999 | Loss: 0.0001 | Episodes: 145 | Win count: 2 | Win rate: 0.400 | time: 53.8 seconds
    Win rate above threshold
    Epoch: 005/14999 | Loss: 0.0011 | Episodes: 148 | Win count: 2 | Win rate: 0.333 | time: 68.8 seconds
    Win rate above threshold
    Epoch: 006/14999 | Loss: 0.0010 | Episodes: 48 | Win count: 3 | Win rate: 0.429 | time: 73.5 seconds
    Win rate above threshold
    Epoch: 007/14999 | Loss: 0.0010 | Episodes: 8 | Win count: 4 | Win rate: 0.500 | time: 74.5 seconds
    Win rate above threshold
    Epoch: 008/14999 | Loss: 0.0013 | Episodes: 147 | Win count: 4 | Win rate: 0.444 | time: 88.4 seconds
    Win rate above threshold
    Epoch: 009/14999 | Loss: 0.0012 | Episodes: 15 | Win count: 5 | Win rate: 0.500 | time: 89.6 seconds
    Win rate above threshold
    Epoch: 010/14999 | Loss: 0.0010 | Episodes: 121 | Win count: 6 | Win rate: 0.545 | time: 99.3 seconds
    Win rate above threshold
    Epoch: 011/14999 | Loss: 0.0012 | Episodes: 7 | Win count: 7 | Win rate: 0.583 | time: 100.1 seconds
    Win rate above threshold
    Epoch: 012/14999 | Loss: 0.0008 | Episodes: 36 | Win count: 8 | Win rate: 0.615 | time: 103.2 seconds
    Win rate above threshold
    Epoch: 013/14999 | Loss: 0.0006 | Episodes: 21 | Win count: 9 | Win rate: 0.643 | time: 105.0 seconds
    Win rate above threshold
    Epoch: 014/14999 | Loss: 0.0004 | Episodes: 135 | Win count: 9 | Win rate: 0.600 | time: 116.0 seconds
    Win rate above threshold
    Epoch: 015/14999 | Loss: 0.0009 | Episodes: 20 | Win count: 10 | Win rate: 0.625 | time: 118.1 seconds
    Win rate above threshold
    Epoch: 016/14999 | Loss: 0.0003 | Episodes: 140 | Win count: 10 | Win rate: 0.588 | time: 130.4 seconds
    Win rate above threshold
    Epoch: 017/14999 | Loss: 0.0006 | Episodes: 142 | Win count: 10 | Win rate: 0.556 | time: 143.7 seconds
    Win rate above threshold
    Epoch: 018/14999 | Loss: 0.0007 | Episodes: 146 | Win count: 10 | Win rate: 0.526 | time: 155.8 seconds
    Win rate above threshold
    Epoch: 019/14999 | Loss: 0.0009 | Episodes: 26 | Win count: 11 | Win rate: 0.550 | time: 157.8 seconds
    Win rate above threshold
    Epoch: 020/14999 | Loss: 0.0009 | Episodes: 7 | Win count: 12 | Win rate: 0.571 | time: 158.6 seconds
    Win rate above threshold
    Epoch: 021/14999 | Loss: 0.0008 | Episodes: 145 | Win count: 12 | Win rate: 0.545 | time: 171.0 seconds
    Win rate above threshold
    Epoch: 022/14999 | Loss: 0.0012 | Episodes: 45 | Win count: 13 | Win rate: 0.565 | time: 174.8 seconds
    Win rate above threshold
    Epoch: 023/14999 | Loss: 0.0008 | Episodes: 135 | Win count: 13 | Win rate: 0.542 | time: 186.4 seconds
    Win rate above threshold
    Epoch: 024/14999 | Loss: 0.0009 | Episodes: 138 | Win count: 13 | Win rate: 0.520 | time: 197.8 seconds
    Win rate above threshold
    Epoch: 025/14999 | Loss: 0.0009 | Episodes: 11 | Win count: 14 | Win rate: 0.538 | time: 198.8 seconds
    Win rate above threshold
    Epoch: 026/14999 | Loss: 0.0007 | Episodes: 121 | Win count: 15 | Win rate: 0.556 | time: 208.6 seconds
    Win rate above threshold
    Epoch: 027/14999 | Loss: 0.0007 | Episodes: 142 | Win count: 15 | Win rate: 0.536 | time: 220.6 seconds
    Win rate above threshold
    Epoch: 028/14999 | Loss: 0.0007 | Episodes: 77 | Win count: 16 | Win rate: 0.552 | time: 227.3 seconds
    Win rate above threshold
    Epoch: 029/14999 | Loss: 0.0007 | Episodes: 138 | Win count: 16 | Win rate: 0.533 | time: 239.0 seconds
    Win rate above threshold
    Epoch: 030/14999 | Loss: 0.0008 | Episodes: 12 | Win count: 17 | Win rate: 0.548 | time: 239.9 seconds
    Win rate above threshold
    Epoch: 031/14999 | Loss: 0.0008 | Episodes: 131 | Win count: 17 | Win rate: 0.531 | time: 251.2 seconds
    Win rate above threshold
    Epoch: 032/14999 | Loss: 0.0006 | Episodes: 61 | Win count: 18 | Win rate: 0.545 | time: 256.8 seconds
    Win rate above threshold
    Epoch: 033/14999 | Loss: 0.0014 | Episodes: 21 | Win count: 19 | Win rate: 0.559 | time: 258.3 seconds
    Win rate above threshold
    Epoch: 034/14999 | Loss: 0.0008 | Episodes: 94 | Win count: 20 | Win rate: 0.571 | time: 266.3 seconds
    Win rate above threshold
    Epoch: 035/14999 | Loss: 0.0008 | Episodes: 112 | Win count: 21 | Win rate: 0.583 | time: 276.5 seconds
    Win rate above threshold
    Epoch: 036/14999 | Loss: 0.0012 | Episodes: 45 | Win count: 22 | Win rate: 0.595 | time: 280.1 seconds
    Win rate above threshold
    Epoch: 037/14999 | Loss: 0.0002 | Episodes: 39 | Win count: 23 | Win rate: 0.605 | time: 283.5 seconds
    Win rate above threshold
    Epoch: 038/14999 | Loss: 0.0006 | Episodes: 44 | Win count: 24 | Win rate: 0.615 | time: 288.0 seconds
    Win rate above threshold
    Epoch: 039/14999 | Loss: 0.0010 | Episodes: 34 | Win count: 25 | Win rate: 0.625 | time: 291.3 seconds
    Win rate above threshold
    Epoch: 040/14999 | Loss: 0.0008 | Episodes: 87 | Win count: 26 | Win rate: 0.634 | time: 299.7 seconds
    Win rate above threshold
    Epoch: 041/14999 | Loss: 0.0011 | Episodes: 39 | Win count: 27 | Win rate: 0.643 | time: 303.6 seconds
    Win rate above threshold
    Epoch: 042/14999 | Loss: 0.0016 | Episodes: 84 | Win count: 28 | Win rate: 0.651 | time: 311.4 seconds
    Win rate above threshold
    Epoch: 043/14999 | Loss: 0.0007 | Episodes: 5 | Win count: 29 | Win rate: 0.659 | time: 312.4 seconds
    Win rate above threshold
    Epoch: 044/14999 | Loss: 0.0013 | Episodes: 6 | Win count: 30 | Win rate: 0.667 | time: 313.0 seconds
    Win rate above threshold
    Epoch: 045/14999 | Loss: 0.0015 | Episodes: 32 | Win count: 31 | Win rate: 0.674 | time: 315.8 seconds
    Win rate above threshold
    Epoch: 046/14999 | Loss: 0.0008 | Episodes: 25 | Win count: 32 | Win rate: 0.681 | time: 318.5 seconds
    Win rate above threshold
    Epoch: 047/14999 | Loss: 0.0003 | Episodes: 25 | Win count: 33 | Win rate: 0.688 | time: 320.7 seconds
    Win rate above threshold
    Epoch: 048/14999 | Loss: 0.0009 | Episodes: 22 | Win count: 34 | Win rate: 0.694 | time: 323.1 seconds
    Win rate above threshold
    Epoch: 049/14999 | Loss: 0.0008 | Episodes: 51 | Win count: 35 | Win rate: 0.700 | time: 327.8 seconds
    Win rate above threshold
    Epoch: 050/14999 | Loss: 0.0016 | Episodes: 59 | Win count: 36 | Win rate: 0.706 | time: 333.0 seconds
    Win rate above threshold
    Epoch: 051/14999 | Loss: 0.0009 | Episodes: 79 | Win count: 37 | Win rate: 0.712 | time: 340.2 seconds
    Win rate above threshold
    Epoch: 052/14999 | Loss: 0.0006 | Episodes: 27 | Win count: 38 | Win rate: 0.717 | time: 342.5 seconds
    Win rate above threshold
    Epoch: 053/14999 | Loss: 0.0011 | Episodes: 41 | Win count: 39 | Win rate: 0.722 | time: 346.2 seconds
    Win rate above threshold
    Epoch: 054/14999 | Loss: 0.0014 | Episodes: 21 | Win count: 40 | Win rate: 0.727 | time: 348.4 seconds
    Win rate above threshold
    Epoch: 055/14999 | Loss: 0.0011 | Episodes: 39 | Win count: 41 | Win rate: 0.732 | time: 352.0 seconds
    Win rate above threshold
    Epoch: 056/14999 | Loss: 0.0012 | Episodes: 39 | Win count: 42 | Win rate: 0.737 | time: 356.1 seconds
    Win rate above threshold
    Epoch: 057/14999 | Loss: 0.0013 | Episodes: 13 | Win count: 43 | Win rate: 0.741 | time: 357.4 seconds
    Win rate above threshold
    Epoch: 058/14999 | Loss: 0.0011 | Episodes: 4 | Win count: 44 | Win rate: 0.746 | time: 357.9 seconds
    Win rate above threshold
    Epoch: 059/14999 | Loss: 0.0017 | Episodes: 24 | Win count: 45 | Win rate: 0.750 | time: 360.3 seconds
    Win rate above threshold
    Epoch: 060/14999 | Loss: 0.0010 | Episodes: 33 | Win count: 46 | Win rate: 0.754 | time: 363.7 seconds
    Win rate above threshold
    Epoch: 061/14999 | Loss: 0.0015 | Episodes: 2 | Win count: 47 | Win rate: 0.758 | time: 364.0 seconds
    Win rate above threshold
    Epoch: 062/14999 | Loss: 0.0016 | Episodes: 17 | Win count: 48 | Win rate: 0.762 | time: 365.9 seconds
    Win rate above threshold
    Epoch: 063/14999 | Loss: 0.0011 | Episodes: 6 | Win count: 49 | Win rate: 0.766 | time: 366.8 seconds
    Win rate above threshold
    Epoch: 064/14999 | Loss: 0.0000 | Episodes: 0 | Win count: 50 | Win rate: 0.769 | time: 367.1 seconds
    Win rate above threshold
    Epoch: 065/14999 | Loss: 0.0008 | Episodes: 1 | Win count: 51 | Win rate: 0.773 | time: 367.5 seconds
    Win rate above threshold
    Epoch: 066/14999 | Loss: 0.0009 | Episodes: 55 | Win count: 52 | Win rate: 0.776 | time: 373.1 seconds
    Win rate above threshold
    Epoch: 067/14999 | Loss: 0.0011 | Episodes: 16 | Win count: 53 | Win rate: 0.779 | time: 374.9 seconds
    Win rate above threshold
    Epoch: 068/14999 | Loss: 0.0012 | Episodes: 19 | Win count: 54 | Win rate: 0.783 | time: 376.8 seconds
    Win rate above threshold
    Epoch: 069/14999 | Loss: 0.0011 | Episodes: 4 | Win count: 55 | Win rate: 0.786 | time: 377.4 seconds
    Win rate above threshold
    Epoch: 070/14999 | Loss: 0.0010 | Episodes: 21 | Win count: 56 | Win rate: 0.789 | time: 380.0 seconds
    Win rate above threshold
    Epoch: 071/14999 | Loss: 0.0017 | Episodes: 44 | Win count: 57 | Win rate: 0.792 | time: 384.0 seconds
    Win rate above threshold
    Epoch: 072/14999 | Loss: 0.0014 | Episodes: 17 | Win count: 58 | Win rate: 0.795 | time: 385.9 seconds
    Win rate above threshold
    Epoch: 073/14999 | Loss: 0.0007 | Episodes: 6 | Win count: 59 | Win rate: 0.797 | time: 386.7 seconds
    Win rate above threshold
    Epoch: 074/14999 | Loss: 0.0006 | Episodes: 31 | Win count: 60 | Win rate: 0.800 | time: 389.5 seconds
    Win rate above threshold
    Epoch: 075/14999 | Loss: 0.0009 | Episodes: 4 | Win count: 61 | Win rate: 0.803 | time: 390.1 seconds
    Win rate above threshold
    Epoch: 076/14999 | Loss: 0.0007 | Episodes: 58 | Win count: 62 | Win rate: 0.805 | time: 395.1 seconds
    Win rate above threshold
    Epoch: 077/14999 | Loss: 0.0003 | Episodes: 8 | Win count: 63 | Win rate: 0.808 | time: 395.9 seconds
    Win rate above threshold
    Epoch: 078/14999 | Loss: 0.0011 | Episodes: 31 | Win count: 64 | Win rate: 0.810 | time: 398.5 seconds
    Win rate above threshold
    Epoch: 079/14999 | Loss: 0.0008 | Episodes: 60 | Win count: 65 | Win rate: 0.812 | time: 6.74 minutes
    Win rate above threshold
    Epoch: 080/14999 | Loss: 0.0008 | Episodes: 64 | Win count: 66 | Win rate: 0.815 | time: 6.84 minutes
    Win rate above threshold
    Epoch: 081/14999 | Loss: 0.0014 | Episodes: 43 | Win count: 67 | Win rate: 0.817 | time: 6.90 minutes
    Win rate above threshold
    Epoch: 082/14999 | Loss: 0.0006 | Episodes: 44 | Win count: 68 | Win rate: 0.819 | time: 6.97 minutes
    Win rate above threshold
    Epoch: 083/14999 | Loss: 0.0013 | Episodes: 22 | Win count: 69 | Win rate: 0.821 | time: 7.01 minutes
    Win rate above threshold
    Epoch: 084/14999 | Loss: 0.0013 | Episodes: 31 | Win count: 70 | Win rate: 0.824 | time: 7.07 minutes
    Win rate above threshold
    Epoch: 085/14999 | Loss: 0.0006 | Episodes: 27 | Win count: 71 | Win rate: 0.826 | time: 7.12 minutes
    Win rate above threshold
    Epoch: 086/14999 | Loss: 0.0014 | Episodes: 5 | Win count: 72 | Win rate: 0.828 | time: 7.14 minutes
    Win rate above threshold
    Epoch: 087/14999 | Loss: 0.0011 | Episodes: 20 | Win count: 73 | Win rate: 0.830 | time: 7.18 minutes
    Win rate above threshold
    Epoch: 088/14999 | Loss: 0.0014 | Episodes: 8 | Win count: 74 | Win rate: 0.831 | time: 7.20 minutes
    Win rate above threshold
    Epoch: 089/14999 | Loss: 0.0007 | Episodes: 21 | Win count: 75 | Win rate: 0.833 | time: 7.24 minutes
    Win rate above threshold
    Epoch: 090/14999 | Loss: 0.0007 | Episodes: 22 | Win count: 76 | Win rate: 0.835 | time: 7.28 minutes
    Win rate above threshold
    Epoch: 091/14999 | Loss: 0.0010 | Episodes: 32 | Win count: 77 | Win rate: 0.837 | time: 7.33 minutes
    Win rate above threshold
    Epoch: 092/14999 | Loss: 0.0011 | Episodes: 45 | Win count: 78 | Win rate: 0.839 | time: 7.40 minutes
    Win rate above threshold
    Epoch: 093/14999 | Loss: 0.0000 | Episodes: 0 | Win count: 79 | Win rate: 0.840 | time: 7.42 minutes
    Win rate above threshold
    Epoch: 094/14999 | Loss: 0.0014 | Episodes: 31 | Win count: 80 | Win rate: 0.842 | time: 7.48 minutes
    Win rate above threshold
    Epoch: 095/14999 | Loss: 0.0010 | Episodes: 4 | Win count: 81 | Win rate: 0.844 | time: 7.49 minutes
    Win rate above threshold
    Epoch: 096/14999 | Loss: 0.0006 | Episodes: 39 | Win count: 82 | Win rate: 0.845 | time: 7.55 minutes
    Win rate above threshold
    Epoch: 097/14999 | Loss: 0.0010 | Episodes: 59 | Win count: 83 | Win rate: 0.847 | time: 7.66 minutes
    Win rate above threshold
    Epoch: 098/14999 | Loss: 0.0003 | Episodes: 11 | Win count: 84 | Win rate: 0.848 | time: 7.68 minutes
    Win rate above threshold
    Epoch: 099/14999 | Loss: 0.0000 | Episodes: 0 | Win count: 85 | Win rate: 0.850 | time: 7.68 minutes
    Win rate above threshold
    Epoch: 100/14999 | Loss: 0.0001 | Episodes: 12 | Win count: 86 | Win rate: 0.851 | time: 7.71 minutes
    Win rate above threshold
    Epoch: 101/14999 | Loss: 0.0004 | Episodes: 17 | Win count: 87 | Win rate: 0.853 | time: 7.74 minutes
    Win rate above threshold
    Epoch: 102/14999 | Loss: 0.0009 | Episodes: 1 | Win count: 88 | Win rate: 0.854 | time: 7.75 minutes
    Win rate above threshold
    Epoch: 103/14999 | Loss: 0.0003 | Episodes: 4 | Win count: 89 | Win rate: 0.856 | time: 7.76 minutes
    Win rate above threshold
    Epoch: 104/14999 | Loss: 0.0006 | Episodes: 44 | Win count: 90 | Win rate: 0.857 | time: 7.83 minutes
    Win rate above threshold
    Epoch: 105/14999 | Loss: 0.0006 | Episodes: 28 | Win count: 91 | Win rate: 0.858 | time: 7.87 minutes
    Win rate above threshold
    Epoch: 106/14999 | Loss: 0.0007 | Episodes: 21 | Win count: 92 | Win rate: 0.860 | time: 7.92 minutes
    Win rate above threshold
    Epoch: 107/14999 | Loss: 0.0003 | Episodes: 16 | Win count: 93 | Win rate: 0.861 | time: 7.95 minutes
    Win rate above threshold
    Epoch: 108/14999 | Loss: 0.0009 | Episodes: 8 | Win count: 94 | Win rate: 0.862 | time: 7.96 minutes
    Win rate above threshold
    Epoch: 109/14999 | Loss: 0.0007 | Episodes: 43 | Win count: 95 | Win rate: 0.864 | time: 8.03 minutes
    Win rate above threshold
    Epoch: 110/14999 | Loss: 0.0008 | Episodes: 22 | Win count: 96 | Win rate: 0.865 | time: 8.06 minutes
    Win rate above threshold
    Epoch: 111/14999 | Loss: 0.0006 | Episodes: 27 | Win count: 97 | Win rate: 0.866 | time: 8.11 minutes
    Win rate above threshold
    Epoch: 112/14999 | Loss: 0.0012 | Episodes: 137 | Win count: 98 | Win rate: 0.867 | time: 8.32 minutes
    Win rate above threshold
    Epoch: 113/14999 | Loss: 0.0009 | Episodes: 44 | Win count: 99 | Win rate: 0.868 | time: 8.39 minutes
    Win rate above threshold
    Epoch: 114/14999 | Loss: 0.0009 | Episodes: 30 | Win count: 100 | Win rate: 0.870 | time: 8.44 minutes
    Win rate above threshold
    Epoch: 115/14999 | Loss: 0.0005 | Episodes: 36 | Win count: 101 | Win rate: 0.871 | time: 8.50 minutes
    Win rate above threshold
    Epoch: 116/14999 | Loss: 0.0013 | Episodes: 154 | Win count: 101 | Win rate: 0.863 | time: 8.73 minutes
    Win rate above threshold
    Epoch: 117/14999 | Loss: 0.0011 | Episodes: 2 | Win count: 102 | Win rate: 0.864 | time: 8.73 minutes
    Win rate above threshold
    Epoch: 118/14999 | Loss: 0.0012 | Episodes: 27 | Win count: 103 | Win rate: 0.866 | time: 8.78 minutes
    Win rate above threshold
    Epoch: 119/14999 | Loss: 0.0008 | Episodes: 49 | Win count: 104 | Win rate: 0.867 | time: 8.85 minutes
    Win rate above threshold
    Epoch: 120/14999 | Loss: 0.0008 | Episodes: 55 | Win count: 105 | Win rate: 0.868 | time: 8.92 minutes
    Win rate above threshold
    Epoch: 121/14999 | Loss: 0.0007 | Episodes: 47 | Win count: 106 | Win rate: 0.869 | time: 8.99 minutes
    Win rate above threshold
    Epoch: 122/14999 | Loss: 0.0007 | Episodes: 21 | Win count: 107 | Win rate: 0.870 | time: 9.03 minutes
    Win rate above threshold
    Epoch: 123/14999 | Loss: 0.0009 | Episodes: 85 | Win count: 108 | Win rate: 0.871 | time: 9.17 minutes
    Win rate above threshold
    Epoch: 124/14999 | Loss: 0.0013 | Episodes: 37 | Win count: 109 | Win rate: 0.872 | time: 9.22 minutes
    Win rate above threshold
    Epoch: 125/14999 | Loss: 0.0007 | Episodes: 11 | Win count: 110 | Win rate: 0.873 | time: 9.24 minutes
    Win rate above threshold
    Epoch: 126/14999 | Loss: 0.0013 | Episodes: 68 | Win count: 111 | Win rate: 0.874 | time: 9.34 minutes
    Win rate above threshold
    Epoch: 127/14999 | Loss: 0.0005 | Episodes: 65 | Win count: 112 | Win rate: 0.875 | time: 9.43 minutes
    Win rate above threshold
    Epoch: 128/14999 | Loss: 0.0012 | Episodes: 6 | Win count: 113 | Win rate: 0.876 | time: 9.44 minutes
    Win rate above threshold
    Epoch: 129/14999 | Loss: 0.0012 | Episodes: 31 | Win count: 114 | Win rate: 0.877 | time: 9.49 minutes
    Win rate above threshold
    Epoch: 130/14999 | Loss: 0.0006 | Episodes: 17 | Win count: 115 | Win rate: 0.878 | time: 9.52 minutes
    Win rate above threshold
    Epoch: 131/14999 | Loss: 0.0013 | Episodes: 30 | Win count: 116 | Win rate: 0.879 | time: 9.57 minutes
    Win rate above threshold
    Epoch: 132/14999 | Loss: 0.0009 | Episodes: 30 | Win count: 117 | Win rate: 0.880 | time: 9.63 minutes
    Win rate above threshold
    Epoch: 133/14999 | Loss: 0.0005 | Episodes: 1 | Win count: 118 | Win rate: 0.881 | time: 9.64 minutes
    Win rate above threshold
    Epoch: 134/14999 | Loss: 0.0006 | Episodes: 61 | Win count: 119 | Win rate: 0.881 | time: 9.73 minutes
    Win rate above threshold
    Epoch: 135/14999 | Loss: 0.0003 | Episodes: 15 | Win count: 120 | Win rate: 0.882 | time: 9.76 minutes
    Win rate above threshold
    Epoch: 136/14999 | Loss: 0.0011 | Episodes: 12 | Win count: 121 | Win rate: 0.883 | time: 9.78 minutes
    Win rate above threshold
    Epoch: 137/14999 | Loss: 0.0006 | Episodes: 46 | Win count: 122 | Win rate: 0.884 | time: 9.86 minutes
    Win rate above threshold
    Epoch: 138/14999 | Loss: 0.0010 | Episodes: 41 | Win count: 123 | Win rate: 0.885 | time: 9.92 minutes
    Win rate above threshold
    Epoch: 139/14999 | Loss: 0.0009 | Episodes: 75 | Win count: 124 | Win rate: 0.886 | time: 10.03 minutes
    Win rate above threshold
    Epoch: 140/14999 | Loss: 0.0006 | Episodes: 60 | Win count: 125 | Win rate: 0.887 | time: 10.13 minutes
    Win rate above threshold
    Epoch: 141/14999 | Loss: 0.0005 | Episodes: 34 | Win count: 126 | Win rate: 0.887 | time: 10.19 minutes
    Win rate above threshold
    Epoch: 142/14999 | Loss: 0.0011 | Episodes: 7 | Win count: 127 | Win rate: 0.888 | time: 10.21 minutes
    Win rate above threshold
    Epoch: 143/14999 | Loss: 0.0011 | Episodes: 54 | Win count: 128 | Win rate: 0.889 | time: 10.28 minutes
    Win rate above threshold
    Epoch: 144/14999 | Loss: 0.0006 | Episodes: 22 | Win count: 129 | Win rate: 0.890 | time: 10.33 minutes
    Win rate above threshold
    Epoch: 145/14999 | Loss: 0.0011 | Episodes: 9 | Win count: 130 | Win rate: 0.890 | time: 10.34 minutes
    Win rate above threshold
    Epoch: 146/14999 | Loss: 0.0009 | Episodes: 31 | Win count: 131 | Win rate: 0.891 | time: 10.39 minutes
    Win rate above threshold
    Epoch: 147/14999 | Loss: 0.0012 | Episodes: 36 | Win count: 132 | Win rate: 0.892 | time: 10.45 minutes
    Win rate above threshold
    Epoch: 148/14999 | Loss: 0.0011 | Episodes: 29 | Win count: 133 | Win rate: 0.893 | time: 10.51 minutes
    Win rate above threshold
    Epoch: 149/14999 | Loss: 0.0009 | Episodes: 25 | Win count: 134 | Win rate: 0.893 | time: 10.55 minutes
    Win rate above threshold
    Epoch: 150/14999 | Loss: 0.0014 | Episodes: 7 | Win count: 135 | Win rate: 0.894 | time: 10.57 minutes
    Win rate above threshold
    Epoch: 151/14999 | Loss: 0.0005 | Episodes: 24 | Win count: 136 | Win rate: 0.895 | time: 10.61 minutes
    Win rate above threshold
    Epoch: 152/14999 | Loss: 0.0005 | Episodes: 41 | Win count: 137 | Win rate: 0.895 | time: 10.69 minutes
    Win rate above threshold
    Epoch: 153/14999 | Loss: 0.0005 | Episodes: 12 | Win count: 138 | Win rate: 0.896 | time: 10.71 minutes
    Win rate above threshold
    Epoch: 154/14999 | Loss: 0.0010 | Episodes: 9 | Win count: 139 | Win rate: 0.897 | time: 10.73 minutes
    Win rate above threshold
    Epoch: 155/14999 | Loss: 0.0007 | Episodes: 30 | Win count: 140 | Win rate: 0.897 | time: 10.78 minutes
    Win rate above threshold
    Epoch: 156/14999 | Loss: 0.0006 | Episodes: 133 | Win count: 140 | Win rate: 0.892 | time: 10.99 minutes
    Win rate above threshold
    Epoch: 157/14999 | Loss: 0.0005 | Episodes: 93 | Win count: 141 | Win rate: 0.892 | time: 11.12 minutes
    Win rate above threshold
    Epoch: 158/14999 | Loss: 0.0006 | Episodes: 25 | Win count: 142 | Win rate: 0.893 | time: 11.17 minutes
    Win rate above threshold
    Epoch: 159/14999 | Loss: 0.0008 | Episodes: 20 | Win count: 143 | Win rate: 0.894 | time: 11.21 minutes
    Win rate above threshold
    Epoch: 160/14999 | Loss: 0.0007 | Episodes: 38 | Win count: 144 | Win rate: 0.894 | time: 11.27 minutes
    Win rate above threshold
    Epoch: 161/14999 | Loss: 0.0004 | Episodes: 50 | Win count: 145 | Win rate: 0.895 | time: 11.36 minutes
    Win rate above threshold
    Epoch: 162/14999 | Loss: 0.0003 | Episodes: 4 | Win count: 146 | Win rate: 0.896 | time: 11.37 minutes
    Win rate above threshold
    Epoch: 163/14999 | Loss: 0.0012 | Episodes: 59 | Win count: 147 | Win rate: 0.896 | time: 11.47 minutes
    Win rate above threshold
    Epoch: 164/14999 | Loss: 0.0012 | Episodes: 17 | Win count: 148 | Win rate: 0.897 | time: 11.50 minutes
    Win rate above threshold
    Epoch: 165/14999 | Loss: 0.0004 | Episodes: 11 | Win count: 149 | Win rate: 0.898 | time: 11.52 minutes
    Win rate above threshold
    Epoch: 166/14999 | Loss: 0.0008 | Episodes: 30 | Win count: 150 | Win rate: 0.898 | time: 11.56 minutes
    Win rate above threshold
    Epoch: 167/14999 | Loss: 0.0010 | Episodes: 59 | Win count: 151 | Win rate: 0.899 | time: 11.67 minutes
    Win rate above threshold
    Epoch: 168/14999 | Loss: 0.0012 | Episodes: 27 | Win count: 152 | Win rate: 0.899 | time: 11.71 minutes
    Win rate above threshold
    Epoch: 169/14999 | Loss: 0.0012 | Episodes: 26 | Win count: 153 | Win rate: 0.900 | time: 11.76 minutes
    Win rate above threshold
    Epoch: 170/14999 | Loss: 0.0007 | Episodes: 128 | Win count: 154 | Win rate: 0.901 | time: 11.94 minutes
    Win rate above threshold
    Epoch: 171/14999 | Loss: 0.0003 | Episodes: 125 | Win count: 155 | Win rate: 0.901 | time: 12.13 minutes
    Win rate above threshold
    Epoch: 172/14999 | Loss: 0.0006 | Episodes: 3 | Win count: 156 | Win rate: 0.902 | time: 12.14 minutes
    Win rate above threshold
    Epoch: 173/14999 | Loss: 0.0004 | Episodes: 37 | Win count: 157 | Win rate: 0.902 | time: 12.20 minutes
    Win rate above threshold
    Epoch: 174/14999 | Loss: 0.0004 | Episodes: 22 | Win count: 158 | Win rate: 0.903 | time: 12.24 minutes
    Win rate above threshold
    Epoch: 175/14999 | Loss: 0.0010 | Episodes: 40 | Win count: 159 | Win rate: 0.903 | time: 12.29 minutes
    Win rate above threshold
    Epoch: 176/14999 | Loss: 0.0012 | Episodes: 36 | Win count: 160 | Win rate: 0.904 | time: 12.35 minutes
    Win rate above threshold
    Epoch: 177/14999 | Loss: 0.0006 | Episodes: 10 | Win count: 161 | Win rate: 0.904 | time: 12.37 minutes
    Win rate above threshold
    Epoch: 178/14999 | Loss: 0.0006 | Episodes: 5 | Win count: 162 | Win rate: 0.905 | time: 12.38 minutes
    Win rate above threshold
    Epoch: 179/14999 | Loss: 0.0000 | Episodes: 0 | Win count: 163 | Win rate: 0.906 | time: 12.38 minutes
    Win rate above threshold
    Epoch: 180/14999 | Loss: 0.0008 | Episodes: 44 | Win count: 164 | Win rate: 0.906 | time: 12.46 minutes
    Win rate above threshold
    Epoch: 181/14999 | Loss: 0.0003 | Episodes: 34 | Win count: 165 | Win rate: 0.907 | time: 12.52 minutes
    Win rate above threshold
    Epoch: 182/14999 | Loss: 0.0007 | Episodes: 113 | Win count: 166 | Win rate: 0.907 | time: 12.68 minutes
    Win rate above threshold
    Epoch: 183/14999 | Loss: 0.0011 | Episodes: 5 | Win count: 167 | Win rate: 0.908 | time: 12.69 minutes
    Win rate above threshold
    Epoch: 184/14999 | Loss: 0.0010 | Episodes: 11 | Win count: 168 | Win rate: 0.908 | time: 12.71 minutes
    Win rate above threshold
    Epoch: 185/14999 | Loss: 0.0011 | Episodes: 48 | Win count: 169 | Win rate: 0.909 | time: 12.78 minutes
    Win rate above threshold
    Epoch: 186/14999 | Loss: 0.0006 | Episodes: 53 | Win count: 170 | Win rate: 0.909 | time: 12.88 minutes
    Win rate above threshold
    Epoch: 187/14999 | Loss: 0.0009 | Episodes: 28 | Win count: 171 | Win rate: 0.910 | time: 12.92 minutes
    Win rate above threshold
    Epoch: 188/14999 | Loss: 0.0006 | Episodes: 17 | Win count: 172 | Win rate: 0.910 | time: 12.95 minutes
    Win rate above threshold
    Epoch: 189/14999 | Loss: 0.0013 | Episodes: 22 | Win count: 173 | Win rate: 0.911 | time: 13.00 minutes
    Win rate above threshold
    Epoch: 190/14999 | Loss: 0.0008 | Episodes: 37 | Win count: 174 | Win rate: 0.911 | time: 13.07 minutes
    Win rate above threshold
    Epoch: 191/14999 | Loss: 0.0011 | Episodes: 5 | Win count: 175 | Win rate: 0.911 | time: 13.10 minutes
    Win rate above threshold
    Epoch: 192/14999 | Loss: 0.0008 | Episodes: 62 | Win count: 176 | Win rate: 0.912 | time: 13.21 minutes
    Win rate above threshold
    Epoch: 193/14999 | Loss: 0.0006 | Episodes: 54 | Win count: 177 | Win rate: 0.912 | time: 13.30 minutes
    Win rate above threshold
    Epoch: 194/14999 | Loss: 0.0007 | Episodes: 45 | Win count: 178 | Win rate: 0.913 | time: 13.37 minutes
    Win rate above threshold
    Epoch: 195/14999 | Loss: 0.0005 | Episodes: 19 | Win count: 179 | Win rate: 0.913 | time: 13.40 minutes
    Win rate above threshold
    Epoch: 196/14999 | Loss: 0.0011 | Episodes: 19 | Win count: 180 | Win rate: 0.914 | time: 13.44 minutes
    Win rate above threshold
    Epoch: 197/14999 | Loss: 0.0009 | Episodes: 19 | Win count: 181 | Win rate: 0.914 | time: 13.48 minutes
    Win rate above threshold
    Epoch: 198/14999 | Loss: 0.0017 | Episodes: 33 | Win count: 182 | Win rate: 0.915 | time: 13.53 minutes
    Win rate above threshold
    Epoch: 199/14999 | Loss: 0.0015 | Episodes: 11 | Win count: 183 | Win rate: 0.915 | time: 13.55 minutes
    Win rate above threshold
    Epoch: 200/14999 | Loss: 0.0007 | Episodes: 31 | Win count: 184 | Win rate: 0.915 | time: 13.60 minutes
    Win rate above threshold
    Epoch: 201/14999 | Loss: 0.0011 | Episodes: 6 | Win count: 185 | Win rate: 0.916 | time: 13.62 minutes
    Win rate above threshold
    Epoch: 202/14999 | Loss: 0.0004 | Episodes: 67 | Win count: 186 | Win rate: 0.916 | time: 13.74 minutes
    Win rate above threshold
    Epoch: 203/14999 | Loss: 0.0015 | Episodes: 9 | Win count: 187 | Win rate: 0.917 | time: 13.76 minutes
    Win rate above threshold
    Epoch: 204/14999 | Loss: 0.0007 | Episodes: 32 | Win count: 188 | Win rate: 0.917 | time: 13.82 minutes
    Win rate above threshold
    Epoch: 205/14999 | Loss: 0.0009 | Episodes: 4 | Win count: 189 | Win rate: 0.917 | time: 13.83 minutes
    Win rate above threshold
    Epoch: 206/14999 | Loss: 0.0011 | Episodes: 37 | Win count: 190 | Win rate: 0.918 | time: 13.89 minutes
    Win rate above threshold
    Epoch: 207/14999 | Loss: 0.0012 | Episodes: 62 | Win count: 191 | Win rate: 0.918 | time: 14.00 minutes
    Win rate above threshold
    Epoch: 208/14999 | Loss: 0.0010 | Episodes: 11 | Win count: 192 | Win rate: 0.919 | time: 14.02 minutes
    Win rate above threshold
    Epoch: 209/14999 | Loss: 0.0010 | Episodes: 13 | Win count: 193 | Win rate: 0.919 | time: 14.05 minutes
    Win rate above threshold
    Epoch: 210/14999 | Loss: 0.0010 | Episodes: 27 | Win count: 194 | Win rate: 0.919 | time: 14.10 minutes
    Win rate above threshold
    Epoch: 211/14999 | Loss: 0.0007 | Episodes: 46 | Win count: 195 | Win rate: 0.920 | time: 14.18 minutes
    Win rate above threshold
    Epoch: 212/14999 | Loss: 0.0010 | Episodes: 84 | Win count: 196 | Win rate: 0.920 | time: 14.32 minutes
    Win rate above threshold
    Epoch: 213/14999 | Loss: 0.0011 | Episodes: 21 | Win count: 197 | Win rate: 0.921 | time: 14.36 minutes
    Win rate above threshold
    Epoch: 214/14999 | Loss: 0.0002 | Episodes: 9 | Win count: 198 | Win rate: 0.921 | time: 14.38 minutes
    Win rate above threshold
    Epoch: 215/14999 | Loss: 0.0013 | Episodes: 42 | Win count: 199 | Win rate: 0.921 | time: 14.45 minutes
    Win rate above threshold
    Epoch: 216/14999 | Loss: 0.0011 | Episodes: 45 | Win count: 200 | Win rate: 0.922 | time: 14.52 minutes
    Win rate above threshold
    Epoch: 217/14999 | Loss: 0.0009 | Episodes: 45 | Win count: 201 | Win rate: 0.922 | time: 14.61 minutes
    Win rate above threshold
    Epoch: 218/14999 | Loss: 0.0008 | Episodes: 5 | Win count: 202 | Win rate: 0.922 | time: 14.63 minutes
    Win rate above threshold
    Epoch: 219/14999 | Loss: 0.0006 | Episodes: 50 | Win count: 203 | Win rate: 0.923 | time: 14.71 minutes
    Win rate above threshold
    Epoch: 220/14999 | Loss: 0.0007 | Episodes: 17 | Win count: 204 | Win rate: 0.923 | time: 14.75 minutes
    Win rate above threshold
    Epoch: 221/14999 | Loss: 0.0006 | Episodes: 37 | Win count: 205 | Win rate: 0.923 | time: 14.82 minutes
    Win rate above threshold
    Epoch: 222/14999 | Loss: 0.0003 | Episodes: 2 | Win count: 206 | Win rate: 0.924 | time: 14.83 minutes
    Win rate above threshold
    Epoch: 223/14999 | Loss: 0.0010 | Episodes: 19 | Win count: 207 | Win rate: 0.924 | time: 14.87 minutes
    Win rate above threshold
    Epoch: 224/14999 | Loss: 0.0003 | Episodes: 26 | Win count: 208 | Win rate: 0.924 | time: 14.91 minutes
    Win rate above threshold
    Epoch: 225/14999 | Loss: 0.0007 | Episodes: 6 | Win count: 209 | Win rate: 0.925 | time: 14.93 minutes
    Win rate above threshold
    Epoch: 226/14999 | Loss: 0.0005 | Episodes: 3 | Win count: 210 | Win rate: 0.925 | time: 14.94 minutes
    Win rate above threshold
    Epoch: 227/14999 | Loss: 0.0004 | Episodes: 2 | Win count: 211 | Win rate: 0.925 | time: 14.95 minutes
    Win rate above threshold
    Epoch: 228/14999 | Loss: 0.0002 | Episodes: 22 | Win count: 212 | Win rate: 0.926 | time: 15.00 minutes
    Win rate above threshold
    Epoch: 229/14999 | Loss: 0.0005 | Episodes: 18 | Win count: 213 | Win rate: 0.926 | time: 15.04 minutes
    Win rate above threshold
    Epoch: 230/14999 | Loss: 0.0007 | Episodes: 29 | Win count: 214 | Win rate: 0.926 | time: 15.11 minutes
    Win rate above threshold
    Epoch: 231/14999 | Loss: 0.0004 | Episodes: 24 | Win count: 215 | Win rate: 0.927 | time: 15.16 minutes
    Win rate above threshold
    Epoch: 232/14999 | Loss: 0.0002 | Episodes: 3 | Win count: 216 | Win rate: 0.927 | time: 15.18 minutes
    Win rate above threshold
    Epoch: 233/14999 | Loss: 0.0004 | Episodes: 7 | Win count: 217 | Win rate: 0.927 | time: 15.20 minutes
    Win rate above threshold
    Epoch: 234/14999 | Loss: 0.0002 | Episodes: 34 | Win count: 218 | Win rate: 0.928 | time: 15.25 minutes
    Win rate above threshold
    Epoch: 235/14999 | Loss: 0.0007 | Episodes: 15 | Win count: 219 | Win rate: 0.928 | time: 15.28 minutes
    Win rate above threshold
    Epoch: 236/14999 | Loss: 0.0007 | Episodes: 2 | Win count: 220 | Win rate: 0.928 | time: 15.29 minutes
    Win rate above threshold
    Epoch: 237/14999 | Loss: 0.0006 | Episodes: 2 | Win count: 221 | Win rate: 0.929 | time: 15.31 minutes
    Win rate above threshold
    Epoch: 238/14999 | Loss: 0.0003 | Episodes: 20 | Win count: 222 | Win rate: 0.929 | time: 15.37 minutes
    Win rate above threshold
    Epoch: 239/14999 | Loss: 0.0003 | Episodes: 55 | Win count: 223 | Win rate: 0.929 | time: 15.46 minutes
    Win rate above threshold
    Epoch: 240/14999 | Loss: 0.0005 | Episodes: 19 | Win count: 224 | Win rate: 0.929 | time: 15.49 minutes
    Win rate above threshold
    Epoch: 241/14999 | Loss: 0.0006 | Episodes: 17 | Win count: 225 | Win rate: 0.930 | time: 15.53 minutes
    Win rate above threshold
    Epoch: 242/14999 | Loss: 0.0012 | Episodes: 27 | Win count: 226 | Win rate: 0.930 | time: 15.59 minutes
    Win rate above threshold
    Epoch: 243/14999 | Loss: 0.0004 | Episodes: 23 | Win count: 227 | Win rate: 0.930 | time: 15.63 minutes
    Win rate above threshold
    Epoch: 244/14999 | Loss: 0.0005 | Episodes: 4 | Win count: 228 | Win rate: 0.931 | time: 15.64 minutes
    Win rate above threshold
    Epoch: 245/14999 | Loss: 0.0008 | Episodes: 16 | Win count: 229 | Win rate: 0.931 | time: 15.67 minutes
    Win rate above threshold
    Epoch: 246/14999 | Loss: 0.0006 | Episodes: 23 | Win count: 230 | Win rate: 0.931 | time: 15.70 minutes
    Win rate above threshold
    Model passed completion check
    Epoch: 247/14999 | Loss: 0.0005 | Episodes: 8 | Win count: 231 | Win rate: 0.931 | time: 15.73 minutes
    Reached 100% win rate at epoch: 247
    n_epoch: 247, max_mem: 512, data: 32, time: 15.74 minutes
    




    944.465965



#### This cell will check to see if the model passes the completion check.<br>Note: This could take several minutes.


```python
# completion_check(model, qmaze)
completion_check(model, qmaze)
show(qmaze)

# Check if the model passes the completion check
show(qmaze)
if completion_check(model, qmaze):
    print("Model successfully trained to completion.")
else:
    print("Model did not pass the completion check.")
```

    Model successfully trained to completion.
    


![png](output_27_1.png)


#### This cell will test your model for one game. It will start the pirate at the top-left corner and run play_game. The agent should find a path from the starting position to the target (treasure).<br><br>The treasure is located in the bottom-right corner.


```python
pirate_start = (0, 0)
play_game(model, qmaze, pirate_start)
show(qmaze)
```




    <matplotlib.image.AxesImage at 0x26067791cc8>




![png](output_29_1.png)


<!-- ## Save and Submit Your Work
After you have finished creating the code for your notebook, save your work. Make sure that your notebook contains your name in the filename (e.g. Doe_Jane_ProjectTwo.ipynb). This will help your instructor access and grade your work easily. Download a copy of your IPYNB file and submit it to Brightspace. Refer to the Jupyter Notebook in Apporto Tutorial if you need help with these tasks. -->

<hr>

## *Old versions of the qtrain function that I ended up not using but keeping for reference just incase*

<hr>


```python
#
# Older versions below
#

# def qtrain(model, maze, **opt):
#     """
#     Trains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.
    
#     Parameters:
#     - model: The neural network model to be trained.
#     - maze: The maze environment as a NumPy array.
#     - **opt: Optional parameters including:
#         - n_epoch: Number of training epochs (default: 15000)
#         - max_memory: Maximum number of episodes to store in memory (default: 1000)
#         - data_size: Number of samples to train on per epoch (default: 50)
    
#     Returns:
#     - seconds: Total training time in seconds.
#     """
    
#     # Access the global exploration factor
#     global epsilon 
    
#     # Retrieve optional parameters or set to default values
#     n_epoch = opt.get('n_epoch', 15000)          # Total number of training epochs
#     max_memory = opt.get('max_memory', 1000)     # Maximum episodes to store in memory
#     data_size = opt.get('data_size', 50)         # Number of training samples per epoch
    
#     # Record the start time to monitor training duration
#     start_time = datetime.datetime.now()
    
#     # Initialize the maze environment
#     qmaze = TreasureMaze(maze)
    
#     # Initialize the experience replay memory
#     experience = GameExperience(model, max_memory=max_memory)
    
#     # Initialize variables to track training progress
#     win_history = []                  # History of game outcomes (1 for win, 0 for loss)
#     hsize = qmaze.maze.size // 2      # Window size for calculating win rate
#     win_rate = 0.0                     # Current win rate
    
#     # Iterate over each epoch
#     for epoch in range(n_epoch):
#         # Randomly select a free cell as the pirate's starting position
#         agent_cell = random.choice(qmaze.free_cells)
        
#         # Reset the maze environment with the pirate at the selected starting position
#         qmaze.reset(agent_cell)
        
#         # Observe the current state of the environment
#         envstate = qmaze.observe()
        
#         # Initialize variables for the current episode
#         game_over = False               # Flag to determine if the game has ended
#         n_episodes = 0                  # Number of steps taken in the current epoch
#         win = False                     # Flag to indicate if the current episode is a win
        
#         # Continue interacting with the environment until the game is over
#         while not game_over:
#             # Store the previous state for experience replay
#             prev_envstate = envstate.copy()
            
#             # Decide whether to explore or exploit based on epsilon-greedy strategy
#             if random.random() < epsilon:
#                 # Exploration: choose a random valid action
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     action = random.choice(valid_actions)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
#             else:
#                 # Exploitation: choose the best action based on current Q-values
#                 q_values = experience.predict(prev_envstate)
                
#                 # Retrieve valid actions to mask invalid ones
#                 valid_actions = qmaze.valid_actions()
#                 if valid_actions:
#                     # Initialize Q-values for all actions as -infinity
#                     q_values_invalid = np.full(num_actions, -np.inf)
#                     # Assign actual Q-values to valid actions
#                     q_values_invalid[valid_actions] = q_values[valid_actions]
#                     # Select the action with the highest Q-value among valid actions
#                     action = np.argmax(q_values_invalid)
#                 else:
#                     # No valid actions available; the game is blocked
#                     action = None
            
#             # Execute the chosen action in the environment
#             if action is not None:
#                 envstate, reward, game_status = qmaze.act(action)
#             else:
#                 # Assign a penalty if the agent is blocked
#                 game_status = 'lose'
#                 reward = -1.0  # Penalty for being blocked
            
#             # Increment the number of steps taken
#             n_episodes += 1
            
#             # Determine if the game has ended
#             game_over = game_status in ['win', 'lose']
            
#             # Store the transition (episode) in experience replay memory
#             episode = [prev_envstate, action, reward, envstate, game_over]
#             experience.remember(episode)
            
#             # Update the win history if the game has ended
#             if game_over:
#                 win = 1 if game_status == 'win' else 0
#                 win_history.append(win)
        
#         # Train the neural network model if enough experiences are available
#         if len(experience.memory) >= data_size:
#             # Retrieve a batch of experiences for training
#             inputs, targets = experience.get_data(data_size=data_size)
            
#             # Train the model on the retrieved batch
#             history = model.fit(inputs, targets, epochs=1, verbose=0)
            
#             # Extract the loss value from the training history
#             loss = history.history['loss'][0]
#         else:
#             # Not enough experiences to train; set loss to None
#             loss = None
        
#         # Calculate the win rate over the most recent hsize episodes
#         if len(win_history) >= hsize:
#             recent_wins = win_history[-hsize:]
#             win_rate = sum(recent_wins) / hsize
#         else:
#             recent_wins = win_history
#             win_rate = sum(recent_wins) / len(recent_wins) if recent_wins else 0.0
        
#         # Calculate the elapsed time since training started
#         dt = datetime.datetime.now() - start_time
#         t = format_time(dt.total_seconds())
        
#         # Prepare the template for epoch information display
#         template = "Epoch: {:05d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | Time: {}"
        
#         # Display loss as 0.0 if it's None to avoid formatting issues
#         loss_display = loss if loss is not None else 0.0
        
#         # Print the current epoch's training information
#         print(template.format(epoch+1, n_epoch, loss_display, n_episodes, sum(win_history[-hsize:]), win_rate, t))
        
#         # Gradually decrease the exploration factor epsilon if the win rate is high
#         if win_rate > 0.9:
#             epsilon = max(epsilon * 0.995, 0.05)  # Ensure epsilon doesn't fall below 0.05
        
#         # Early stopping condition: if win rate is 100% over the window and the agent passes the completion check
#         if win_rate == 1.0 and completion_check(model, qmaze):
#             print("Reached 100% win rate at epoch: {}".format(epoch+1))
#             break
    
#     # Calculate the total training time
#     dt = datetime.datetime.now() - start_time
#     seconds = dt.total_seconds()
#     t = format_time(seconds)
    
#     # Print the training summary
#     print("Training completed in epoch: {}, max_memory: {}, data_size: {}, time: {}".format(epoch+1, max_memory, data_size, t))
    
#     return seconds

# # def qtrain(model, maze, **opt):
# #     """
# #     Trains the pirate agent using Deep Q-Learning to navigate the maze and find the treasure.
    
# #     Parameters:
# #     - model: The neural network model to be trained.
# #     - maze: The maze environment as a NumPy array.
# #     - **opt: Optional parameters including:
# #         - n_epoch: Number of training epochs (default: 15000)
# #         - max_memory: Maximum number of episodes to store in memory (default: 1000)
# #         - data_size: Number of samples to train on per epoch (default: 50)
    
# #     Returns:
# #     - seconds: Total training time in seconds.
# #     """
    
# #     # Access the global exploration factor
# #     global epsilon 
    
# #     # Retrieve optional parameters or set to default values
# #     n_epoch = opt.get('n_epoch', 15000)          # Total number of training epochs
# #     max_memory = opt.get('max_memory', 1000)     # Maximum episodes to store in memory
# #     data_size = opt.get('data_size', 50)         # Number of training samples per epoch
    
# #     # Record the start time to monitor training duration
# #     start_time = datetime.datetime.now()
    
# #     # Initialize the maze environment
# #     qmaze = TreasureMaze(maze)
    
# #     # Initialize the experience replay memory
# #     experience = GameExperience(model, max_memory=max_memory)
    
# #     # Initialize variables to track training progress
# #     win_history = []                  # History of game outcomes (1 for win, 0 for loss)
# #     hsize = qmaze.maze.size // 2      # Window size for calculating win rate
# #     win_rate = 0.0                     # Current win rate
    
# #     # Iterate over each epoch
# #     for epoch in range(n_epoch):
# #         # Randomly select a free cell as the pirate's starting position
# #         agent_cell = random.choice(qmaze.free_cells)
        
# #         # Reset the maze environment with the pirate at the selected starting position
# #         qmaze.reset(agent_cell)
        
# #         # Observe the current state of the environment
# #         envstate = qmaze.observe()
        
# #         # Initialize variables for the current episode
# #         game_over = False               # Flag to determine if the game has ended
# #         n_episodes = 0                  # Number of steps taken in the current epoch
# #         win = False                     # Flag to indicate if the current episode is a win
        
# #         # Continue interacting with the environment until the game is over
# #         while not game_over:
# #             prev_envstate = envstate.copy()   # Store the previous state
            
# #             # Decide whether to explore or exploit based on epsilon-greedy strategy
# #             if random.random() < epsilon:
# #                 # Exploration: choose a random valid action
# #                 valid_actions = qmaze.valid_actions()
# #                 if valid_actions:
# #                     action = random.choice(valid_actions)
# #                 else:
# #                     # No valid actions available; the game is blocked
# #                     action = None
# #             else:
# #                 # Exploitation: choose the best action based on current Q-values
# #                 q_values = experience.predict(prev_envstate)
                
# #                 # Mask invalid actions by setting their Q-values to -infinity
# #                 valid_actions = qmaze.valid_actions()
# #                 if valid_actions:
# #                     q_values_invalid = np.full(num_actions, -np.inf)
# #                     q_values_invalid[valid_actions] = q_values[valid_actions]
# #                     action = np.argmax(q_values_invalid)
# #                 else:
# #                     # No valid actions available; the game is blocked
# #                     action = None
            
# #             # Execute the chosen action in the environment
# #             if action is not None:
# #                 envstate, reward, game_status = qmaze.act(action)
# #             else:
# #                 # Assign a penalty if the agent is blocked
# #                 game_status = 'lose'
# #                 reward = -1.0
            
# #             # Increment the number of steps taken
# #             n_episodes += 1
            
# #             # Determine if the game has ended
# #             game_over = game_status in ['win', 'lose']
            
# #             # Store the transition (episode) in experience replay memory
# #             episode = [prev_envstate, action, reward, envstate, game_over]
# #             experience.remember(episode)
            
# #             # Update the win history if the game has ended
# #             if game_over:
# #                 win = 1 if game_status == 'win' else 0
# #                 win_history.append(win)
        
# #         # Train the neural network model if enough experiences are available
# #         if len(experience.memory) >= data_size:
# #             # Retrieve a batch of experiences for training
# #             inputs, targets = experience.get_data(data_size=data_size)
            
# #             # Train the model on the retrieved batch
# #             history = model.fit(inputs, targets, epochs=1, verbose=0)
            
# #             # Extract the loss value from the training history
# #             loss = history.history['loss'][0]
# #         else:
# #             # Not enough experiences to train; set loss to None
# #             loss = None
        
# #         # Calculate the win rate over the most recent hsize episodes
# #         if len(win_history) >= hsize:
# #             recent_wins = win_history[-hsize:]
# #             win_rate = sum(recent_wins) / hsize
# #         else:
# #             recent_wins = win_history
# #             win_rate = sum(recent_wins) / len(recent_wins) if recent_wins else 0.0
        
# #         # Calculate the elapsed time since training started
# #         dt = datetime.datetime.now() - start_time
# #         t = format_time(dt.total_seconds())
        
# #         # Prepare the template for epoch information display
# #         template = "Epoch: {:05d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | Time: {}"
        
# #         # Display loss as 0.0 if it's None to avoid formatting issues
# #         loss_display = loss if loss is not None else 0.0
        
# #         # Print the current epoch's training information
# #         print(template.format(epoch+1, n_epoch, loss_display, n_episodes, sum(win_history[-hsize:]), win_rate, t))
        
# #         # Gradually decrease the exploration factor epsilon if the win rate is high
# #         if win_rate > 0.9:
# #             epsilon = max(epsilon * 0.995, 0.05)  # Ensure epsilon doesn't fall below 0.05
        
# #         # Early stopping condition: if win rate is 100% over the window and the agent passes the completion check
# #         if win_rate == 1.0 and completion_check(model, qmaze):
# #             print("Reached 100% win rate at epoch: {}".format(epoch+1))
# #             break
    
# #     # Calculate the total training time
# #     dt = datetime.datetime.now() - start_time
# #     seconds = dt.total_seconds()
# #     t = format_time(seconds)
    
# #     # Print the training summary
# #     print("Training completed in epoch: {}, max_memory: {}, data_size: {}, time: {}".format(epoch+1, max_memory, data_size, t))
    
# #     return seconds

# # #
# # # Original Version that came with the project pre-edits/ added qtrain function to impliment the Deep Q-Learning algorithm
# # #

# # # def qtrain(model, maze, **opt):

# # #     # exploration factor
# # #     global epsilon 

# # #     # number of epochs
# # #     n_epoch = opt.get('n_epoch', 15000)

# # #     # maximum memory to store episodes
# # #     max_memory = opt.get('max_memory', 1000)

# # #     # maximum data size for training
# # #     data_size = opt.get('data_size', 50)

# # #     # start time
# # #     start_time = datetime.datetime.now()

# # #     # Construct environment/game from numpy array: maze (see above)
# # #     qmaze = TreasureMaze(maze)

# # #     # Initialize experience replay object
# # #     experience = GameExperience(model, max_memory=max_memory)
    
# # #     win_history = []   # history of win/lose game
# # #     hsize = qmaze.maze.size//2   # history window size
# # #     win_rate = 0.0
    
# # #     # pseudocode:
# # #     # For each epoch:
# # #     #    Agent_cell = randomly select a free cell
# # #     #    Reset the maze with agent set to above position
# # #     #    Hint: Review the reset method in the TreasureMaze.py class.
# # #     #    envstate = Environment.current_state
# # #     #    Hint: Review the observe method in the TreasureMaze.py class.
# # #     #    While state is not game over:
# # #     #        previous_envstate = envstate
# # #     #        Action = randomly choose action (left, right, up, down) either by exploration or by exploitation
# # #     #        envstate, reward, game_status = qmaze.act(action)
# # #     #    Hint: Review the act method in the TreasureMaze.py class.
# # #     #        episode = [previous_envstate, action, reward, envstate, game_status]
# # #     #        Store episode in Experience replay object
# # #     #    Hint: Review the remember method in the GameExperience.py class.
# # #     #        Train neural network model and evaluate loss
# # #     #    Hint: Call GameExperience.get_data to retrieve training data (input and target) and pass to model.fit method 
# # #     #          to train the model. You can call model.evaluate to determine loss.
# # #     #    If the win rate is above the threshold and your model passes the completion check, that would be your epoch.


# # #     #Print the epoch, loss, episodes, win count, and win rate for each epoch
# # #         dt = datetime.datetime.now() - start_time
# # #         t = format_time(dt.total_seconds())
# # #         template = "Epoch: {:03d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | time: {}"
# # #         print(template.format(epoch, n_epoch-1, loss, n_episodes, sum(win_history), win_rate, t))
# # #         # We simply check if training has exhausted all free cells and if in all
# # #         # cases the agent won.
# # #         if win_rate > 0.9 : epsilon = 0.05
# # #         if sum(win_history[-hsize:]) == hsize and completion_check(model, qmaze):
# # #             print("Reached 100%% win rate at epoch: %d" % (epoch,))
# # #             break
    
    
# # #     # Determine the total time for training
# # #     dt = datetime.datetime.now() - start_time
# # #     seconds = dt.total_seconds()
# # #     t = format_time(seconds)

# # #     print("n_epoch: %d, max_mem: %d, data: %d, time: %s" % (epoch, max_memory, data_size, t))
# # #     return seconds

# # # # This is a small utility for printing readable time strings:
# # # def format_time(seconds):
# # #     if seconds < 400:
# # #         s = float(seconds)
# # #         return "%.1f seconds" % (s,)
# # #     elif seconds < 4000:
# # #         m = seconds / 60.0
# # #         return "%.2f minutes" % (m,)
# # #     else:
# # #         h = seconds / 3600.0
# # #         return "%.2f hours" % (h,)
```
